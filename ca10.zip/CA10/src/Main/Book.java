package Main;

public class Book {
	private String title;
	private String author;
	private boolean isAvailable;
	public Book() {
		this("Unknown", "Unknown");
	}
	public Book(String title, String author) {
		this.title = title;
		this.author = author;
		this.isAvailable = true;
	}
	public void borrowBook() {
		this.isAvailable = false;
	}
	public void returnBook() {
		this.isAvailable = true;
	}
	public void displayDetails() {
		System.out.println("Book Details: Title: " + this.title + ", Author: " + this.author + ", Available? " + (isAvailable ? "Yes" : "No"));
	}
	public static void main(String[] args) {
		// Create books using different constructors
        Book defaultBook = new Book();
        Book customBook = new Book("Pride and Prejudice", "Jane Austen");

        // Display initial details of the books
        System.out.println("Initial Book Details:");
        defaultBook.displayDetails();
        customBook.displayDetails();

        // Borrow each book
        defaultBook.borrowBook();
        customBook.borrowBook();

        // Display details after borrowing
        System.out.println("\nAfter Borrowing Books:");
        defaultBook.displayDetails();
        customBook.displayDetails();

        // Return one book
        defaultBook.returnBook();

        // Display final details
        System.out.println("\nFinal Book Details:");
        defaultBook.displayDetails();
        customBook.displayDetails();
		
	}
}
