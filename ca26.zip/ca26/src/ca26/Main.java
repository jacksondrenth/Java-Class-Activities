package ca26;

public class Main {
    public static void main(String[] args) {
        RouletteSimulator game = new RouletteSimulator(1000); // Start the game with 1000 credits
        System.out.println(game.makeBet(100, "red")); // Place a bet on red
        System.out.println(game.makeBet(200, "even")); // Place a bet on even numbers
        System.out.println(game.makeBet(50, "13")); // Place a bet on the number 13
    }
}
