package ca26;

import java.util.Random;

public class RouletteSimulator {
	private static int numCredits;
	
	public RouletteSimulator(int intialCredits) {
		numCredits = intialCredits;
	}
	
	public static int spin() {
		Random rand = new Random();
		int spin = rand.nextInt(37);
		return spin;
	}
	
	public static String getColor(int resultNum) {
		if (resultNum == 0) {
			return "green";
		}
		else if (resultNum % 2 == 0) {
			return "black";
		}
		else {
			return "red";
		}
	}
	public static String getParity(int resultNum) {
		if (resultNum == 0) {
			return "none";
		}
		else if (resultNum % 2 == 0) {
			return "even";
		}
		else {
			return "odd";
		}
	}
	public static void addCredits(int credits) {
		numCredits += credits;
	}
	
	public static int checkCredits() {
		return numCredits;
	}
	public String makeBet(int betAmount, String betType) {
		if (numCredits < betAmount) {
			return "Insufficient Funds.";
		}
		else if (betAmount < 1) {
			return "Invalid bet size.";
		}
		else {
			numCredits -= betAmount;
		}
		int spin = spin();
		String color = getColor(spin);
		String parity = getParity(spin);
		String sSpin = Integer.toString(spin);
		if (betType == sSpin) {
			numCredits += betAmount * 35;
			
			return "The result is: " + spin + ", " + color + ", " + parity + ". You won: " + numCredits + " credits";
		}
		else if (betType == parity || betType == color) {
			numCredits += betAmount * 2;
			return "The result is: " + spin + ", " + color + ", " + parity + ". You won: " + numCredits + " credits";
		}
		else {
			return "The result is: " + spin + ", " + color + ", " + parity + ". You lose.";
		}
	}
}
