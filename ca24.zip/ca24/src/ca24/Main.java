package ca24;

import java.util.Scanner;

public class Main {
	public static int recursiveSum(int n) {
		if (n == 0 ) {
			return 0;
		} 
		else {
			return n + recursiveSum(n-1);
		}
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter a positive integer to calculate the sum up to:");
		int input = scanner.nextInt();
		while (input <= 0) {
			System.out.println("Please eneter a positive Integer:");
			input = scanner.nextInt();
		}
		int result = recursiveSum(input);
		System.out.println("the sum of number from 1 to " + input + " is " + result);
		scanner.close();
	}
}
