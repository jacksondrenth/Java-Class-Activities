package ca21;

public class Main {
    public static void main(String[] args) {
        Driver driver = new Driver("John Doe");
        driver.displayInfo();

        Vehicle myCar = new Car();
        myCar.displayVehicleType();
        myCar.startEngine();
        myCar.activateGPS();

        Vehicle myMotorcycle = new Motorcycle();
        myMotorcycle.displayVehicleType();
        myMotorcycle.startEngine();
        myMotorcycle.activateGPS();

        Vehicle myBoat = new Boat();
        myBoat.displayVehicleType();
        myBoat.startEngine();
        myBoat.activateGPS();
    }
}

interface Navigation {
	public void activateGPS();
}

abstract class Vehicle implements Navigation {
	private String vehicleType;
	
	public Vehicle(String v) {
		this.vehicleType = v;
	}
	
	abstract void startEngine();
	
	public void displayVehicleType() {
		System.out.println("Vehicle type: " + this.vehicleType);
	}
}


 class Car extends Vehicle {
	public Car() {
		super("Car");
	}
	
	@Override
	public void startEngine() {
		displayVehicleType();
		System.out.println("Key Turned");
	}
	
	@Override 
	public void activateGPS() {
		System.out.println("Activating the car's GPS");
	}
	
}

 class Boat extends Vehicle {
	public Boat() {
		super("Boat");
	}
	
	@Override
	public void startEngine() {
		displayVehicleType();
		System.out.println("Button Pressed");
	}
	
	@Override 
	public void activateGPS() {
		System.out.println("Activating the Boat's GPS");
	}
}

 class Motorcycle extends Vehicle {
	public Motorcycle() {
		super("Motorcycle");
	}
	
	@Override
	public void startEngine() {
		displayVehicleType();
		System.out.println("Switch Flipped");
	}
	
	@Override 
	public void activateGPS() {
		System.out.println("Activating the Motorcycle's GPS");
	}
}

class Driver {
	private String name;
	
	public Driver(String name) {
		this.name = name; 
	}
	
	public void displayInfo() {
		System.out.println("Driver: " + name);
	}
}
