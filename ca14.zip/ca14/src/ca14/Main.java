package ca14;

public class Main {

	public static void main(String[] args) {
		int[] originalArray = {1, 2, 3, 4, 5, 6};
		int[] copiedArray = new int[originalArray.length];
		ArrayCopy.copyArray(originalArray, copiedArray);
		String ogNums = arrayPrint(originalArray);
		String copyNums = arrayPrint(copiedArray);
		System.out.println("Original Array: " + ogNums);
		System.out.println("Coppied Array: " + copyNums);

	}
	public static String arrayPrint(int[] arr) {
		String nums = "";
		for (int i = 0; i < arr.length; i++) {
			nums += arr[i] + " ";
		}
		return nums;
	}

}
