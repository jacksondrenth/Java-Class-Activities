package ca14;

public class ArrayCopy {
	public static void copyArray(int[] source, int[] destination) {
		for (int i = 0; i < source.length; i++) {
			destination[i] = source[i];
		}
	}
}
