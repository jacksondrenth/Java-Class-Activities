package ca27;

import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        // Example test array to demonstrate the sorting functionality
        int[] testArray = {20, 35, -15, 7, 55, 1, -22};
        System.out.println("Original Array: " + Arrays.toString(testArray));

        // Applying the insertion sort algorithm to the test array
        ArraySorter.sortArray(testArray);

        // Printing the sorted array to show the outcome of the sort
        System.out.println("Sorted Array: " + Arrays.toString(testArray));
    }
    
}

