package Main;

public class Registrar {
	public void processRegistration (Student student) {
		System.out.println("Student " + student.name + " has been registered for the course: " + student.course);
	}
}
