package Main;

public class Student {
	String name;
	String course;
	public static void main(String[] args) {
		// Create a new student
        Student student = new Student("Alice");

        // Enroll the student in a course
        student.enrollCourse("Mathematics");

        // Create a registrar
        Registrar registrar = new Registrar();

        // Register the student using the registrar
        student.register(registrar); // Outputs registration details
	}
	public Student(String name) {
		this.name = name;
	}
	public void enrollCourse(String course) {
		this.course = course;
	}
	public void register(Registrar registrar) {
		registrar.processRegistration(this);
	}

}

