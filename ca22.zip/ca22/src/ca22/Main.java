package ca22;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        try {
            File file = new File("data.txt");
            Scanner inputFile = new Scanner(file);

            // Assuming you want to read lines from the file if it exists
            while (inputFile.hasNextLine()) {
                String line = inputFile.nextLine();
                System.out.println(line);
            }
            inputFile.close(); // It's important to close the scanner
        } catch (FileNotFoundException e) {
            System.out.println("File not found.");
        }
    }
}