package main;

public class ArrayOptimizer {
    public static void optimizeArray(int[] arr) {
        for (int currentPos = 0; currentPos < arr.length - 1; currentPos++) {
            int minIndex = currentPos;
            
            for (int i = currentPos + 1; i < arr.length; i++) {

                if (arr[i] < arr[minIndex]) {
                    minIndex = i;
                }
            }
            

            if (minIndex != currentPos) {
                int temp = arr[currentPos];
                arr[currentPos] = arr[minIndex];
                arr[minIndex] = temp;
            }
        }
    }
}