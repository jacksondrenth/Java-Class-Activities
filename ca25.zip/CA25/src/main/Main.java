package main;

public class Main {
	    public static void main(String[] args) {
        int[] testArray = {29, 10, 14, 37, 13};
        ArrayOptimizer.optimizeArray(testArray);
        System.out.println(java.util.Arrays.toString(testArray));
        // Expected Output: [10, 13, 14, 29, 37]
	}
}

