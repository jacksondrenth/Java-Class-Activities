package ca23;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        Scanner inputFile = null;
        try {
            File file = new File("log.txt"); // Try to open the file
            inputFile = new Scanner(file); // Initialize the scanner to read the file

            while (inputFile.hasNextLine()) {
                String line = inputFile.nextLine(); // Read and print each line
                System.out.println(line);
            }
        } catch (FileNotFoundException e) {
            System.out.println("Error: " + e.getMessage()); // Print error message if file is not found
        } finally {
            if (inputFile != null) {
                inputFile.close(); // Ensure the Scanner is closed in the finally block
            }
            System.out.println("Execution of file reading is completed."); // Additional finally block statement
        }
    }
}
