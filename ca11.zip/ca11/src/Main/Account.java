package Main;

public class Account {
	String accountNumber;
	double balance;
	public Account() {
		accountNumber = "00000000";
		balance = 0.0;
	}
	public Account(String acNum) {
		this.accountNumber = acNum;
		this.balance = 0.0;
	}
	public Account(String acNum, double bal) {
		this.accountNumber = acNum;
		this.balance = bal;
	}
	public void deposit(double amount) {
		this.balance += amount;
	}
	public void withdraw(double amount) {
		this.balance -= amount;
	}
	public void displayAccountDetails() {
		System.out.println("Account Number: " + this.accountNumber + " Balance: " + this.balance);
	}
	public static void main(String[] args) {
		Account defaultAccount = new Account();
        Account specificAccount = new Account("12345678");
        Account loadedAccount = new Account("87654321", 500.0);

        // Display initial details of all accounts
        System.out.println("Initial Account Details:");
        defaultAccount.displayAccountDetails();
        specificAccount.displayAccountDetails();
        loadedAccount.displayAccountDetails();

        // Perform transactions
        specificAccount.deposit(300.0);
        loadedAccount.withdraw(200.0);

        // Display final details after transactions
        System.out.println("\nFinal Account Details:");
        defaultAccount.displayAccountDetails();
        specificAccount.displayAccountDetails();
        loadedAccount.displayAccountDetails();
	}
}
