package ca20;

public class Main {
	public static void main(String[] args) {
		Shape myShape = new Shape();
		myShape.draw();
		
		Shape myCircle = new Circle();
		myCircle.draw();
		
		Shape mySquare = new Square();
		mySquare.draw();
		
		Shape myTriangle = new Triangle();
		myTriangle.draw();
	}
	
}

class Shape {
	void draw() {
		System.out.println("Drawing a shape.");
	}
}

class Circle extends Shape {
	void draw() {
		System.out.println("Drawing a circle.");
	}
}

class Square extends Shape {
	void draw() {
		System.out.println("Drawing a square.");
	}
}

class Triangle extends Shape {
	void draw() {
		System.out.println("Drawing a triangle.");
	}
}

