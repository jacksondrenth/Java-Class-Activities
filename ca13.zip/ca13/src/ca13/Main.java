package ca13;

public class Main {
	public static void main(String[] args) {
        int[] numbers = {10, 20, 30, 40, 50, 60, 70, 80, 90, 100};
        int sum = 0;
        int max = numbers[0];
        for (int i=0; i < numbers.length; i++) {
        	System.out.println("Element at index " + i + " is: " + numbers[i]);
        	sum += numbers[i];
        	if (max < numbers[i]) {
        		max = numbers[i];
        	}
        }
        int maxIndex = findIndex(numbers, max);
        System.out.println("The sum is: " + sum);
        System.out.println("The max, " + max + ", was found at index: " + maxIndex);
    }
	public static int findIndex(int[] arr, int target) {
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] == target) {
				return i;
			}
		}
		return -1;
	}
}
